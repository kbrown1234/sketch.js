let xpos = 50;
let ypos = 50;
let dx = 5;
let dy = 3;

function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(50);
  ellipse(xpos,ypos,30,30);
  if(xpos>=width-20 || xpos==20)
    {
      dx= -dx
    }
  if(ypos>=height-20 || ypos==20)
    {
      dy = -dy
    }
  xpos = xpos +dx;
  ypos = ypos +dy;
  textSize(50);
  text("Pong",350,400);
}
 